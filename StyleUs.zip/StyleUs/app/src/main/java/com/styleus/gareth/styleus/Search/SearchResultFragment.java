package com.styleus.gareth.styleus.Search;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.styleus.gareth.styleus.R;

/**
 * Created by Gareth on 12/03/2018.
 */

public class SearchResultFragment extends Fragment {
    private static final String TAG = "SearchResultFragment";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_searchresults, container, false);

        return view;
    }
}
